import os
import yaml
from app.db import get_conn
from app.ingest.discover import discover_from_rss, discover_from_page
from app.ingest.fetch import fetch_text
from app.ingest.classify import classify
from app.ingest.extract import detect_lang, extract_deadline, extract_amount, domain

def upsert_source(cur, s):
    cur.execute(
        """INSERT INTO sources(name,url,kind,country_hint,language_hint,active)
           VALUES (%s,%s,%s,%s,%s,TRUE)
           ON CONFLICT (url) DO UPDATE SET active=TRUE""",
        (s["name"], s["url"], s["kind"], s.get("country_hint"), s.get("language_hint"))
    )

def insert_opp(cur, **row):
    cur.execute(
        """INSERT INTO opportunities
           (title, org_name, opp_type, country, countries_eligible, accepts_international,
            amount_min, amount_max, currency, deadline, industry_tags, stage,
            language, summary, raw_url, source_domain, source_kind)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
           ON CONFLICT (raw_url) DO NOTHING""",
        (
            row["title"], row.get("org_name"), row.get("opp_type"), row.get("country"),
            row.get("countries_eligible"), row.get("accepts_international", False),
            row.get("amount_min"), row.get("amount_max"), row.get("currency"),
            row.get("deadline"), row.get("industry_tags"), row.get("stage"),
            row.get("language"), row.get("summary"), row["raw_url"],
            row.get("source_domain"), row.get("source_kind","unknown")
        )
    )

def main():
    if "DATABASE_URL" not in os.environ:
        raise RuntimeError("DATABASE_URL env var is required")

    with open("app/sources.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    sources = cfg.get("sources", [])

    # upsert sources in DB
    with get_conn() as conn:
        with conn.cursor() as cur:
            for s in sources:
                upsert_source(cur, s)
        conn.commit()

    inserted = 0
    for s in sources:
        urls = []
        if s["kind"] == "rss":
            urls = discover_from_rss(s["url"])
        elif s["kind"] == "page":
            urls = discover_from_page(s["url"])
        else:
            continue

        for u in urls[:120]:
            try:
                text = fetch_text(u)
                if len(text) < 800:
                    continue

                opp_type = classify(text)
                lang = detect_lang(text)
                deadline = extract_deadline(text)
                amin, amax, cur = extract_amount(text)

                title = text[:140].strip()
                summary = text[:700].strip()

                with get_conn() as conn:
                    with conn.cursor() as curdb:
                        insert_opp(
                            curdb,
                            title=title,
                            opp_type=opp_type,
                            country=s.get("country_hint"),
                            countries_eligible=[s.get("country_hint")] if s.get("country_hint") else None,
                            accepts_international=False,
                            amount_min=amin,
                            amount_max=amax,
                            currency=cur,
                            deadline=deadline,
                            industry_tags=[],
                            stage=None,
                            language=lang,
                            summary=summary,
                            raw_url=u,
                            source_domain=domain(u),
                            source_kind="unknown",
                        )
                    conn.commit()
                    inserted += 1
            except Exception:
                continue

    print({"inserted": inserted})

if __name__ == "__main__":
    main()
